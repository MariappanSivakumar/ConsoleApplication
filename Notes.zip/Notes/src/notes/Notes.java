package notes;

public class Notes {
    
    public static void main(String[] args) {
        new Process();
    }    
}
