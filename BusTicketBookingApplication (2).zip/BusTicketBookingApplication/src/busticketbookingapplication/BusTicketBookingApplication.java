
package busticketbookingapplication;

import Controller.Process;

public class BusTicketBookingApplication {

    public static void main(String[] args) {
            new Process().getLogin();
    }
    
}
