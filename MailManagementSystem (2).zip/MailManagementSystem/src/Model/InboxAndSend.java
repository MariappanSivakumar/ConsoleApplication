
package Model;
public class InboxAndSend {
    private String sender = new String();
    private String  receiver = new String();
    private String subject =  new String();
    private String content = new String();
    
    public void setSender(String sender)
    {
        this.sender = sender;
    }
    public void setReceiver(String receiver)
    {
        this.receiver = receiver;
    }
    public void setSubject(String subject)
    {
        this.content = content;
    }
    public void setContent(String content)
    {
        this.subject = subject;
    }
    public String getSender()
    {
        return sender;
    }
     public String getReceiver()
    {
        return receiver;
    }
     public String getSubject()
    {
        return subject;
    }
     public String getsContent()
    {
        return sender;
    }
    
}
