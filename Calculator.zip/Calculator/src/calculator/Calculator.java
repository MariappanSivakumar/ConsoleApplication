
package calculator;

import userview.ConsoleCalculatorView;

public class Calculator {

    public static void main(String[] args) {
       new ConsoleCalculatorView().consoleProcess();
    }
    
}
