
package flightticketbooking;

import controller.InternalProcess;

public class FlightTicketBooking {

    public static void main(String[] args) {
        new InternalProcess().init();
    }
    
}
