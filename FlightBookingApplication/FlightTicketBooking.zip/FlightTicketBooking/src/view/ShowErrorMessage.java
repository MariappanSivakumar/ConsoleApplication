
package view;

public class ShowErrorMessage {
    public void error(String errorMessage)
    {
        System.err.println(errorMessage);
    }
}
